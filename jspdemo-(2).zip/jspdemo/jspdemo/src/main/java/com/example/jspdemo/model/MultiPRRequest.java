package com.example.jspdemo.model;



import java.util.List;

public class MultiPRRequest {
    private String baseBranch;
    private List<String> prUrls;

    // Getters and setters
    public String getBaseBranch() {
        return baseBranch;
    }

    public void setBaseBranch(String baseBranch) {
        this.baseBranch = baseBranch;
    }

    public List<String> getPrUrls() {
        return prUrls;
    }

    public void setPrUrls(List<String> prUrls) {
        this.prUrls = prUrls;
    }
}
