package com.example.jspdemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.example.jspdemo.model.PRStats;
import com.example.jspdemo.service.GitHubService;
//import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pr")
public class PRController {

    private final GitHubService gitHubService;

    public PRController(GitHubService gitHubService) {
        this.gitHubService = gitHubService;
    }

    @GetMapping("/{owner}/{repo}/{prNumber}")
    public PRStats getPRStats(@PathVariable String owner,
                              @PathVariable String repo,
                              @PathVariable int prNumber) throws Exception {
        return gitHubService.fetchPRStats(owner, repo, prNumber);
    }

}
