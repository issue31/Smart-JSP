package com.example.jspdemo.service;

import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;


@Service
public class LocalGitAnalyzer {

    public void cloneRepo(String repoUrl, String localPath) throws GitAPIException {
        Git.cloneRepository()
                .setURI(repoUrl)
                .setDirectory(new File(localPath))
                .call();
    }

    public void checkoutBranch(String localPath, String branchName) throws IOException, GitAPIException {
        try (Git git = Git.open(new File(localPath))) {
            git.checkout().setName(branchName).call();
        }
    }
}
