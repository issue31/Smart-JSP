package com.example.jspdemo.service;


import org.springframework.stereotype.Service;
import java.util.List;

import com.example.jspdemo.model.MultiPRRequest;
import com.example.jspdemo.model.MultiPRResponse;
import com.example.jspdemo.model.PRModuleResult;

@Service
public class PRDiffService {

    public MultiPRResponse comparePRs(MultiPRRequest request) {
        // Hardcoded response
        List<PRModuleResult> results = List.of(
                new PRModuleResult("module-a", 120, 45),
                new PRModuleResult("module-b", 80, 30),
                new PRModuleResult("module-c", 200, 100)
        );

        return new MultiPRResponse(results);
    }
}
