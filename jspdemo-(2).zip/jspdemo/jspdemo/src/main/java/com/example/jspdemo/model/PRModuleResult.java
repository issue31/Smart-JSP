package com.example.jspdemo.model;


public class PRModuleResult {
    private String module;
    private int linesAdded;
    private int linesDeleted;

    // Constructors
    public PRModuleResult() {}

    public PRModuleResult(String module, int linesAdded, int linesDeleted) {
        this.module = module;
        this.linesAdded = linesAdded;
        this.linesDeleted = linesDeleted;
    }

    // Getters and Setters
    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public int getLinesAdded() {
        return linesAdded;
    }

    public void setLinesAdded(int linesAdded) {
        this.linesAdded = linesAdded;
    }

    public int getLinesDeleted() {
        return linesDeleted;
    }

    public void setLinesDeleted(int linesDeleted) {
        this.linesDeleted = linesDeleted;
    }
}
