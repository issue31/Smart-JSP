package com.example.jspdemo.service;

import com.example.jspdemo.model.PRStats;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;






import com.example.jspdemo.model.PRStats;
import org.json.JSONObject;
import org.springframework.stereotype.Service;


@Service
public class GitHubService {
    private static final String API_BASE = "https://api.github.com/repos/";
    private final HttpClient client = HttpClient.newHttpClient();

    public PRStats fetchPRStats(String owner, String repo, int prNumber) throws IOException, InterruptedException {
        String apiUrl = API_BASE + owner + "/" + repo + "/pulls/" + prNumber;
        String browserUrl = "https://github.com/" + owner + "/" + repo + "/pull/" + prNumber;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .header("Accept", "application/vnd.github.v3+json")
                .header("Authorization", getAuthHeader())
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new IOException("GitHub API error: " + response.statusCode());
        }

        JSONObject json = new JSONObject(response.body());
        return new PRStats(json.getInt("additions"), json.getInt("deletions"), browserUrl);
    }

    private String getAuthHeader() {
        String token = System.getenv("GITHUB_TOKEN");
        return (token != null && !token.isEmpty()) ? "Bearer " + token : "";
    }
}
