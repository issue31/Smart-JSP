package com.example.jspdemo.controller;



import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

import com.example.jspdemo.model.MultiPRRequest;
import com.example.jspdemo.model.MultiPRResponse;
import com.example.jspdemo.service.PRDiffService;

@RestController
@RequestMapping("/api/git")
public class PRDiffController {

    private final PRDiffService prDiffService;

    @Autowired
    public PRDiffController(PRDiffService prDiffService) {
        this.prDiffService = prDiffService;
    }

    @PostMapping("/pr-url-diff/multi")
    public MultiPRResponse compareMultiplePRs(@RequestBody MultiPRRequest request) {
        return prDiffService.comparePRs(request);
    }
}
