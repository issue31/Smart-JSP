package com.example.jspdemo.model;



import java.util.List;

public class MultiPRResponse {
    private List<PRModuleResult> results;

    public MultiPRResponse(List<PRModuleResult> results) {
        this.results = results;
    }

    // Getter
    public List<PRModuleResult> getResults() {
        return results;
    }

    public void setResults(List<PRModuleResult> results) {
        this.results = results;
    }
}
