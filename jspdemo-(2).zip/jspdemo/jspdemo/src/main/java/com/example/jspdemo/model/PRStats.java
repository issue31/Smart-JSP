package com.example.jspdemo.model;


public record PRStats(int additions, int deletions, String browserUrl) {
    public int total() {
        return additions + deletions;
    }
}


